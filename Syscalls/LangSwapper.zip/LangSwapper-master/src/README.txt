This plugin is aimed towards end users who enjoy playing games from another region (*cough* Japan *cough*) on the PSP. Well, mainly those who wish to 
keep the in-game HOME menu set to the language specified in the XMB Sytem Settings. Meaning, if you set your language to English, German, French, 
or anything else while playing a Japanese game (Fan translated or not), the in-game HOME menu will always be set to use that language.

This also patches the Savedata Utility to use the language selected in the XMB as well.
